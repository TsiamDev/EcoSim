# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 14:21:39 2022

@author: TsiamDev
"""

import os
#from subprocess import Popen

#subprocess.call([r'C:\Users\kosts\Desktop\Python\runserver.bat'])
os.system("taskkill /f /im  python.exe")

#p = Popen("batch.bat", cwd=r"C:\Path\to\batchfolder")
#stdout, stderr = p.communicate()