# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 20:08:46 2022

@author: kosts
"""

import os


os.system('cmd /k "C:\\Users\\kosts\\Documents\\GitHub\\EcoSim\\Networking\\EcoSimEnv\\Scripts\\activate.bat \&& cd C:\\Users\\kosts\\Documents\\GitHub\\EcoSim\\Networking\\EcoSimSite \&& python manage.py runserver 192.168.1.8:80"')    
 