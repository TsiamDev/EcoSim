# -*- coding: utf-8 -*-
"""
Created on Tue Aug 23 23:24:44 2022

@author: TsiamDev
"""

class MyPoint:
    def __init__(self, _x, _y):
        self.x = _x
        self.y = _y
    
    def move(self, _x, _y):
        self.x = self.x + _x
        self.y = self.y + _y