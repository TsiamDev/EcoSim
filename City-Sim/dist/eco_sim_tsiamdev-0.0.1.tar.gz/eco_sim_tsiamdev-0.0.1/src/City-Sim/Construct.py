# -*- coding: utf-8 -*-
"""
Created on Sun Aug  7 21:18:21 2022

@author: TsiamDev
"""

import random
from Const import CONST

class Construct:
    def __init__(self):
        print("New Consrtuct")
        
        #choose construct's type
        #self.type = random.randint(1, len(CONST.types))
        
        
#c = Construct(0)
#print(c.type)